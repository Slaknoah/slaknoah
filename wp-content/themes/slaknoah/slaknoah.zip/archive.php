<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package slaknoah
 */

get_header();
?>

<?php
get_sidebar();
get_footer();
